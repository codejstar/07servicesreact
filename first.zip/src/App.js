import './App.css';
// import Country from './component/Country';
// import Songs from './component/Songs';
// import Location from './component/Location';
import Resturant from './component/Resturant';

function App() {
  // let coutries = [{name:'India'},{name:'America'},{name:'Koria'},{name:'England'},{name:'Jamaica'}]
  return (
    <div className="App">
          {/* <Location/> */}
          {/* <Songs/> */}
          {/* <Country country={coutries}/> */}
          <Resturant/>
    </div>
  );
}

export default App;
