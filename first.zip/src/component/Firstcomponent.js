import React from 'react'

const Firstcomponent = () => {
  return (
    <>
        <div>
            <h1>About Me</h1>
            <h2>My name is Jagdeep Jakhu.</h2>
            <p>My college Name is DAVIET.</p>
            <p>I live in punjab.</p>
             <p>I am 23 years old.</p>
        </div>
    </>
  )
}

export default Firstcomponent